
class DoublyLinkedList {
    Node2 head;

    // Function to insert a new node at the end of the doubly linked list
    void insert(int newData) {
        Node2 newNode = new Node2(newData);

        if (head == null) {
            head = newNode;
        } else {
            Node2 last = head;
            while (last.next != null) {
                last = last.next;
            }
            last.next = newNode;
            newNode.prev = last;
        }
    }

    // Function to traverse the doubly linked list in forward direction
    void forwardTraversal() {
        Node2 current = head;
        System.out.println("Forward Traversal:");

        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }

        System.out.println();
    }

    // Function to traverse the doubly linked list in backward direction
    void backwardTraversal() {
        Node2 last = head;

        // Move to the end of the list
        while (last.next != null) {
            last = last.next;
        }

        System.out.println("Backward Traversal:");

        // Traverse in backward direction
        while (last != null) {
            System.out.print(last.data + " ");
            last = last.prev;
        }

        System.out.println();
    }

    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();

        // Insert elements into the doubly linked list
        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);

        // Traverse the doubly linked list in forward direction
        list.forwardTraversal();

        // Traverse the doubly linked list in backward direction
        list.backwardTraversal();
    }
}
