
class Node2 {
    int data;
    Node2 next;
    Node2 prev;

    public Node2(int data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}

