
public class DeleteFirstOccurrenceLinkedList {
    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();

        // Insert elements into the linked list
        linkedList.insert(10);
        linkedList.insert(20);
        linkedList.insert(30);
        linkedList.insert(40);
        linkedList.insert(50);

        System.out.println("Original Linked List:");
        linkedList.display();

        int keyToDelete = 30;
        linkedList.deleteFirstOccurrence(keyToDelete);

        System.out.println("Linked List after deleting first occurrence of " + keyToDelete + ":");
        linkedList.display();
    }
}