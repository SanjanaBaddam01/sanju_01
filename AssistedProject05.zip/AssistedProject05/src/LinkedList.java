
class LinkedList {
    private Node head;

    public LinkedList() {
        this.head = null;
    }

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            newNode.next = head;
            head = newNode;
        }
    }

    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void deleteFirstOccurrence(int key) {
        Node current = head;
        Node prev = null;

        // Traverse the list to find the key
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        // If key is not present
        if (current == null) {
            System.out.println("Key not found in the list.");
            return;
        }

        // If key is found, delete the node
        if (prev == null) {
            // If the key is in the head node
            head = current.next;
        } else {
            // If the key is in a non-head node
            prev.next = current.next;
        }

        System.out.println("First occurrence of key " + key + " deleted.");
    }
}

