
import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
    public static void main(String[] args) {
        // Create a queue using LinkedList
        Queue<Integer> queue = new LinkedList<>();

        // Insert elements into the queue (enqueue)
        queue.offer(10);
        queue.offer(20);
        queue.offer(30);

        // Display the elements in the queue
        System.out.println("Queue elements: " + queue);

        // Remove elements from the queue (dequeue)
        int removedElement = queue.poll();
        System.out.println("Dequeued element: " + removedElement);

        // Display the elements in the queue after dequeue operation
        System.out.println("Queue elements after dequeue: " + queue);

        // Peek at the front element without removing it
        int frontElement = queue.peek();
        System.out.println("Front element (peek): " + frontElement);

        // Display the elements in the queue after peek operation
        System.out.println("Queue elements after peek: " + queue);
    }
}
