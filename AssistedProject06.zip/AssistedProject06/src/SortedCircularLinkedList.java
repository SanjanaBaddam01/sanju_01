
class SortedCircularLinkedList {
    Node1 head;

    // Function to insert a new element into a sorted circular linked list
    void insert(int newData) {
        Node1 newNode = new Node1(newData);
        Node1 current = head;

        // If the list is empty, insert the new node as the only node
        if (current == null) {
            newNode.next = newNode;
            head = newNode;
        } else if (current.data >= newNode.data) {
            // If the new node's data is smaller than the head's data, insert it at the beginning
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            // Find the appropriate position to insert the new node
            while (current.next != head && current.next.data < newNode.data) {
                current = current.next;
            }

            // Insert the new node
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Function to display the elements of the circular linked list
    void display() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        Node1 current = head;

        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);

        System.out.println();
    }

    public static void main(String[] args) {
        SortedCircularLinkedList list = new SortedCircularLinkedList();

        // Insert elements into the sorted circular linked list
        list.insert(10);
        list.insert(5);
        list.insert(20);
        list.insert(3);

        // Display the elements of the sorted circular linked list
        System.out.println("Sorted Circular Linked List:");
        list.display();
    }
}
