
public class Stack1 {
    public static void main(String[] args) {
        Stack stack = new Stack();

        // Insert elements into the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);

        // Remove elements from the stack
        stack.pop();

        // Get the top element without removing it
        System.out.println("Top element: " + stack.peek());

        // Remove remaining elements from the stack
        stack.pop();
        stack.pop();

        // Try to pop from an empty stack (will throw EmptyStackException)
        // stack.pop();
    }
}