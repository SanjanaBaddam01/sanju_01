
import java.util.EmptyStackException;

class Stack {
    private static final int MAX_SIZE = 100;
    private int[] array;
    private int top;

    public Stack() {
        this.array = new int[MAX_SIZE];
        this.top = -1;
    }

    // Method to check if the stack is empty
    public boolean isEmpty() {
        return top == -1;
    }

    // Method to check if the stack is full
    public boolean isFull() {
        return top == MAX_SIZE - 1;
    }

    // Method to insert an element into the stack (push)
    public void push(int data) {
        if (isFull()) {
            System.out.println("Stack overflow. Cannot push element: " + data);
        } else {
            array[++top] = data;
            System.out.println("Pushed element: " + data);
        }
    }

    // Method to remove the top element from the stack (pop)
    public int pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        } else {
            int poppedElement = array[top--];
            System.out.println("Popped element: " + poppedElement);
            return poppedElement;
        }
    }

    // Method to get the top element without removing it
    public int peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        } else {
            return array[top];
        }
    }
}
