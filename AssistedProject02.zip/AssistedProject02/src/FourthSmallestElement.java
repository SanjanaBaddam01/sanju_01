
import java.util.Arrays;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] unsortedArray = {12, 5, 3, 9, 20, 15, 8, 10};
        
        int fourthSmallest = findFourthSmallestElement(unsortedArray);

        System.out.println("The fourth smallest element in the array is: " + fourthSmallest);
    }

    private static int findFourthSmallestElement(int[] arr) {
        if (arr.length < 4) {
            System.out.println("Array does not have at least four elements.");
            return -1; // Return a sentinel value indicating an error
        }

        // Sort the array in ascending order
        Arrays.sort(arr);

        // The fourth smallest element is at index 3 (0-based index)
        return arr[3];
    }
}
